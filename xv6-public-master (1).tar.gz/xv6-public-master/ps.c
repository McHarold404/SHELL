#include "types.h"
#include "fcntl.h"
#include "stat.h"
#include "user.h"

int 
main(void) 
{
    pinfo();
    exit();
}